<script setup>
import { name } from '@/../package.json'
import { onMounted, ref, watch } from 'vue'
import IconButton from './IconButton.vue'
import { useRoute, useRouter } from 'vue-router';
import menuAside from '@/menuAside';
import DrawerButton from './drawer/DrawerButton.vue';

function children(data, coll = []) {
  if(data.length == 0) return coll
  return data.map(el => ({...el, name: el.label, path: el.to, children: children(el?.menu || [])}))
}
const routes = menuAside().map(el => ({...el, name: el.label, path: el.to, children: children(el?.menu || [])}))
const route = useRoute()
const router = useRouter()

const opened = ref(route.path)

const props = defineProps({
  open: {
    type: Boolean,
    default: false
  }
})

function logout() {
  localStorage.clear && localStorage.clear()
  location.href = '/login'
}

console.log(routes)

</script>
<template>
  <div class="relative overflow-y-auto h-full">
    <div ref="scrollbar" class="transition-transform  px-4 relative h-full w-full overflow-y-scroll z-20 flex flex-col gap-[1.6rem]">
      <div class="relative flex flex-col gap-8 z-10">
        <div class="h-16 flex gap-2 items-center">
          <svg width="38" height="36" viewBox="0 0 38 36" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="37.3879" height="35.9499" rx="17.975" fill="#263558"/>
            <path d="M10.932 22.6149C10.2786 22.6149 9.7093 22.4655 9.22397 22.1669C8.73864 21.8682 8.3653 21.4622 8.10397 20.9489C7.84264 20.4262 7.71197 19.8382 7.71197 19.1849C7.71197 18.4382 7.8473 17.8129 8.11797 17.3089C8.38864 16.7955 8.7573 16.4082 9.22397 16.1469C9.69064 15.8855 10.2133 15.7549 10.792 15.7549C11.3706 15.7549 11.8933 15.8715 12.36 16.1049C12.8266 16.3382 13.1953 16.6649 13.466 17.0849C13.7366 17.5049 13.872 17.9949 13.872 18.5549L13.816 19.4369H9.60197C9.60197 20.3609 9.74197 21.0189 10.022 21.4109C10.3113 21.7935 10.6846 21.9849 11.142 21.9849C11.6273 21.9849 12.0193 21.8729 12.318 21.6489C12.626 21.4249 12.9013 21.1495 13.144 20.8229L13.578 21.1449C13.4473 21.3502 13.27 21.5695 13.046 21.8029C12.8313 22.0269 12.5513 22.2182 12.206 22.3769C11.87 22.5355 11.4453 22.6149 10.932 22.6149ZM9.60197 18.8069H11.982C11.982 17.8829 11.87 17.2482 11.646 16.9029C11.4313 16.5575 11.1466 16.3849 10.792 16.3849C10.5866 16.3849 10.3906 16.4595 10.204 16.6089C10.0266 16.7582 9.88197 17.0102 9.76997 17.3649C9.65797 17.7102 9.60197 18.1909 9.60197 18.8069ZM21.9516 22.6149C21.6249 22.6149 21.3123 22.5495 21.0136 22.4189C20.7149 22.2882 20.4209 22.0782 20.1316 21.7889C19.8516 21.4902 19.5576 21.0889 19.2496 20.5849L17.8496 18.2469H17.2896V22.4749H15.4556V15.0549C15.4556 14.6349 15.3949 14.2989 15.2736 14.0469C15.1616 13.7855 14.8956 13.6549 14.4756 13.6549H14.3356V13.2349H18.1996C18.4516 13.2349 18.7409 13.2535 19.0676 13.2909C19.4036 13.3189 19.7396 13.3842 20.0756 13.4869C20.4116 13.5802 20.7243 13.7202 21.0136 13.9069C21.3029 14.0935 21.5363 14.3409 21.7136 14.6489C21.8909 14.9475 21.9796 15.3209 21.9796 15.7689C21.9796 16.2635 21.8676 16.6695 21.6436 16.9869C21.4289 17.2949 21.1489 17.5375 20.8036 17.7149C20.4583 17.8922 20.0943 18.0322 19.7116 18.1349L21.1816 20.5849C21.5363 21.1822 21.8629 21.5789 22.1616 21.7749C22.4603 21.9709 22.7123 22.0875 22.9176 22.1249V22.4749C22.8429 22.5122 22.7076 22.5449 22.5116 22.5729C22.3249 22.6009 22.1383 22.6149 21.9516 22.6149ZM17.2896 17.6869H18.1296C18.3536 17.6869 18.5776 17.6542 18.8016 17.5889C19.0256 17.5235 19.2263 17.4162 19.4036 17.2669C19.5903 17.1175 19.7396 16.9169 19.8516 16.6649C19.9636 16.4129 20.0196 16.1049 20.0196 15.7409C20.0196 15.3769 19.9636 15.0735 19.8516 14.8309C19.7489 14.5789 19.6043 14.3782 19.4176 14.2289C19.2403 14.0702 19.0396 13.9582 18.8156 13.8929C18.6009 13.8275 18.3816 13.7949 18.1576 13.7949C18.0829 13.7949 17.9709 13.7995 17.8216 13.8089C17.6816 13.8182 17.5043 13.8462 17.2896 13.8929V17.6869ZM23.0746 22.4749L25.4406 19.5489L24.0966 17.2949C23.9006 16.9589 23.6859 16.6975 23.4526 16.5109C23.2286 16.3242 23.0092 16.2122 22.7946 16.1749V15.8949H24.1246C24.5819 15.8949 24.9412 15.9975 25.2026 16.2029C25.4732 16.3989 25.7112 16.6695 25.9166 17.0149L26.5886 18.1489L28.4226 15.8949H29.3606L26.9946 18.8069L28.3526 21.0749C28.5486 21.4109 28.7586 21.6722 28.9826 21.8589C29.2159 22.0455 29.4399 22.1575 29.6546 22.1949V22.4749H28.3246C27.8672 22.4749 27.5032 22.3769 27.2326 22.1809C26.9712 21.9755 26.7379 21.7002 26.5326 21.3549L25.8466 20.2209L24.0126 22.4749H23.0746Z" fill="white"/>
          </svg>
          <span class="font-bold text-base"> Ethiopia</span>
        </div>
        <DrawerButton :routes="routes" />
      </div>
      <div class="flex flex-col p-2 gap-4 justify-end min-h-[10rem] max-h-[10rem] flex-1">
        <div class="border-b py-2 flex justify-between border-drawer-separator/30 text-text-secondary-clr items-center">
          <div class="h-10 items-center bg-bg-clr px-2 rounded-full flex justify-between w-full">
            <div class="flex gap-4 items-center">
              <div class="grid place-items-center text-text-secondary-clr">
                <h-icon class="text-text-secondary-clr rotate-45" name="wi-moon-waxing-crescent-3"></h-icon>
              </div>
              <p>Night Mode</p>
            </div>
            <!-- <ToggleInput /> -->
          </div>
        </div>
        <div class="text-center text-sm font-bold">
          HealthConnect
        </div>
      </div>
    </div>
  </div>
</template>