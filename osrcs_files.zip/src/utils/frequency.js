export default ["Once a day", "Twice a day", "Trice a day", "Four times a day"];
