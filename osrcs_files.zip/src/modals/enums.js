export const FileType = {
  GLOBAL_SPINNER: 'Global Spinner',
  SPINNER: 'Spinner',
  MODAL: 'Modal',
}