<script setup>
</script>
<template>
	<div class="p-4 bg-black/50 min-h-full grid place-items-center w-full">
		<slot />
	</div>
</template>