<script setup></script>

<template>
  <div
    class="w-12 h-12 rounded-full animate-spin border-2 border-dashed border-indigo-500 border-t-transparent"
  ></div>
</template>
